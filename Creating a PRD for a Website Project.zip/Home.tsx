/**
 * Home Page
 * Design System: Bold & Sophisticated
 * Features: Hero with background image, asymmetric layout, services preview, CTA sections
 */

import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { SectionDivider, AccentBar, LayeredCard } from '@/components/SectionDivider';
import { ArrowRight, Zap, Shield, Lightbulb } from 'lucide-react';

const HERO_BG = 'https://d2xsxph8kpxj0f.cloudfront.net/310519663792582809/AewPWMfHSGzmaAxXho86iv/hero-background-jtjQQbDABiYwmhVHcUEqPZ.webp';
const SERVICES_HERO = 'https://d2xsxph8kpxj0f.cloudfront.net/310519663792582809/AewPWMfHSGzmaAxXho86iv/services-hero-image-fpmFZZfzVNAst3LGVb4yaW.webp';

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      {/* Hero Section */}
      <section
        className="relative min-h-screen flex items-center justify-center overflow-hidden"
        style={{
          backgroundImage: `url('${HERO_BG}')`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      >
        <div className="absolute inset-0 bg-black/30" />
        <div className="relative container mx-auto px-4 text-center">
          <div className="mb-6 inline-block">
            <AccentBar width="w-24" />
          </div>
          <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 leading-tight">
            We Don't Just Solve Problems
          </h1>
          <p className="text-xl md:text-2xl text-white/90 mb-8 max-w-2xl mx-auto">
            We anticipate them. Our forward-thinking approach combines deep expertise with innovative solutions tailored to your unique challenges.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link href="/contact">
            <Button className="bg-accent text-accent-foreground hover:bg-accent/90 px-8 py-6 text-lg transform hover:scale-105 active:scale-97 transition-all duration-200">
              Let's Build Something Remarkable
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
          </Link>
          <Link href="/services">
            <Button
              variant="outline"
              className="border-white text-white hover:bg-white/10 px-8 py-6 text-lg"
            >
              Explore Our Services
            </Button>
          </Link>
          </div>
        </div>
      </section>

      {/* Services Preview Section */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <div className="mb-12">
            <AccentBar width="w-16" color="#0ea5a5" />
            <h2 className="text-4xl md:text-5xl font-bold text-foreground mt-4 mb-4">
              Our Core Services
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl">
              We deliver comprehensive solutions across strategy, implementation, and optimization.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <LayeredCard withAccent>
              <div className="flex items-start gap-4">
                <div className="p-3 bg-accent/10 rounded-lg">
                  <Zap className="w-6 h-6 text-accent" />
                </div>
                <div className="flex-1">
                  <h3 className="text-xl font-bold text-foreground mb-2">Strategic Consulting</h3>
                  <p className="text-muted-foreground">
                    Transform your business with data-driven insights and actionable strategies tailored to your market.
                  </p>
                </div>
              </div>
            </LayeredCard>

            <LayeredCard withAccent>
              <div className="flex items-start gap-4">
                <div className="p-3 bg-accent/10 rounded-lg">
                  <Shield className="w-6 h-6 text-accent" />
                </div>
                <div className="flex-1">
                  <h3 className="text-xl font-bold text-foreground mb-2">Implementation</h3>
                  <p className="text-muted-foreground">
                    Execute your vision with precision. Our team ensures seamless integration and measurable results.
                  </p>
                </div>
              </div>
            </LayeredCard>

            <LayeredCard withAccent>
              <div className="flex items-start gap-4">
                <div className="p-3 bg-accent/10 rounded-lg">
                  <Lightbulb className="w-6 h-6 text-accent" />
                </div>
                <div className="flex-1">
                  <h3 className="text-xl font-bold text-foreground mb-2">Innovation & Growth</h3>
                  <p className="text-muted-foreground">
                    Stay ahead of the curve with our innovation workshops and growth optimization programs.
                  </p>
                </div>
              </div>
            </LayeredCard>
          </div>

          <div className="mt-12 text-center">
          <Link href="/services">
            <Button className="bg-accent text-accent-foreground hover:bg-accent/90 px-8 py-6 transform hover:scale-105 active:scale-97 transition-all duration-200">
              View All Services
              <ArrowRight className="ml-2 w-4 h-4" />
            </Button>
          </Link>
          </div>
        </div>
      </section>

      {/* Divider */}
      <SectionDivider position="bottom" color="#f8f5f0" />

      {/* Why Choose Us Section */}
      <section className="py-20 bg-foreground text-background">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl md:text-5xl font-bold mb-6" style={{ fontFamily: "'Playfair Display', serif" }}>
                Why Partner With Us
              </h2>
              <ul className="space-y-4">
                {[
                  'Proven track record with Fortune 500 companies',
                  'Expert team with 15+ years of industry experience',
                  'Customized solutions, not off-the-shelf templates',
                  'Transparent communication and measurable KPIs',
                  'Dedicated support throughout your journey',
                ].map((item, idx) => (
                  <li key={idx} className="flex items-start gap-3">
                    <div className="w-6 h-6 rounded-full bg-accent flex items-center justify-center flex-shrink-0 mt-1">
                      <span className="text-sm font-bold text-foreground">✓</span>
                    </div>
                    <span className="text-lg">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <img
                src={SERVICES_HERO}
                alt="Why Choose Us"
                className="rounded-lg shadow-xl w-full h-auto"
              />
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
            Ready to Transform Your Business?
          </h2>
          <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
            Let's discuss how our expertise can drive growth and innovation for your organization.
          </p>
          <Link href="/contact">
            <Button className="bg-accent text-accent-foreground hover:bg-accent/90 px-8 py-6 text-lg transform hover:scale-105 active:scale-97 transition-all duration-200">
              Schedule a Consultation
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
          </Link>
        </div>
      </section>

      <Footer />
    </div>
  );
}
