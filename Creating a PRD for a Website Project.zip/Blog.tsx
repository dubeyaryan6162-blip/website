/**
 * Blog Page
 * Design System: Bold & Sophisticated
 * Features: Featured articles, blog grid, search and filtering
 */

import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { SectionDivider, AccentBar } from '@/components/SectionDivider';
import { Calendar, User, ArrowRight } from 'lucide-react';

const BLOG_POSTS = [
  {
    id: 1,
    title: 'The Future of Digital Transformation: What Leaders Need to Know',
    excerpt: 'Explore emerging trends in digital transformation and how forward-thinking organizations are staying ahead of disruption.',
    author: 'Sarah Johnson',
    date: 'June 15, 2024',
    category: 'Digital Transformation',
    readTime: '8 min read',
  },
  {
    id: 2,
    title: 'Building High-Performing Teams in a Remote-First World',
    excerpt: 'Strategies for maintaining culture, collaboration, and productivity when your team is distributed across geographies.',
    author: 'Michael Chen',
    date: 'June 10, 2024',
    category: 'Organizational Development',
    readTime: '6 min read',
  },
  {
    id: 3,
    title: 'Data-Driven Decision Making: A Practical Guide',
    excerpt: 'Learn how to leverage data analytics to make informed strategic decisions and drive measurable business outcomes.',
    author: 'Emily Rodriguez',
    date: 'June 5, 2024',
    category: 'Strategy',
    readTime: '10 min read',
  },
  {
    id: 4,
    title: 'Innovation in Uncertain Times: Strategies for Sustainable Growth',
    excerpt: 'How to foster a culture of innovation and maintain growth momentum even in volatile market conditions.',
    author: 'Sarah Johnson',
    date: 'May 28, 2024',
    category: 'Innovation',
    readTime: '7 min read',
  },
  {
    id: 5,
    title: 'The Role of AI in Modern Business Strategy',
    excerpt: 'Understanding artificial intelligence and its transformative impact on business operations and competitive advantage.',
    author: 'Michael Chen',
    date: 'May 20, 2024',
    category: 'Technology',
    readTime: '9 min read',
  },
  {
    id: 6,
    title: 'Customer-Centric Transformation: Putting Your Customers First',
    excerpt: 'How to restructure your organization around customer needs and create lasting competitive differentiation.',
    author: 'Emily Rodriguez',
    date: 'May 12, 2024',
    category: 'Customer Experience',
    readTime: '6 min read',
  },
];

export default function Blog() {
  const featuredPost = BLOG_POSTS[0];
  const recentPosts = BLOG_POSTS.slice(1);

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-b from-secondary to-background">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl">
            <AccentBar width="w-16" color="#0ea5a5" />
            <h1 className="text-5xl md:text-6xl font-bold text-foreground mt-4 mb-6">
              Insights & Updates
            </h1>
            <p className="text-xl text-muted-foreground">
              Stay informed with our latest articles, industry insights, and thought leadership on strategy, innovation, and business transformation.
            </p>
          </div>
        </div>
      </section>

      {/* Featured Article */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div className="bg-secondary rounded-lg h-80" />
            <div>
              <div className="inline-block mb-4">
                <span className="bg-accent/10 text-accent px-3 py-1 rounded-full text-sm font-semibold">
                  {featuredPost.category}
                </span>
              </div>
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
                {featuredPost.title}
              </h2>
              <p className="text-muted-foreground mb-6 leading-relaxed">
                {featuredPost.excerpt}
              </p>
              <div className="flex flex-wrap gap-4 mb-6 text-sm text-muted-foreground">
                <div className="flex items-center gap-2">
                  <User className="w-4 h-4" />
                  {featuredPost.author}
                </div>
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4" />
                  {featuredPost.date}
                </div>
                <span>{featuredPost.readTime}</span>
              </div>
              <a href="#" className="inline-flex items-center gap-2 text-accent font-semibold hover:gap-3 transition-all">
                Read Article
                <ArrowRight className="w-4 h-4" />
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Divider */}
      <SectionDivider position="bottom" color="#f8f5f0" />

      {/* Recent Articles */}
      <section className="py-20 bg-foreground text-background">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl md:text-5xl font-bold mb-12" style={{ fontFamily: "'Playfair Display', serif" }}>
            Recent Articles
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {recentPosts.map((post) => (
              <div
                key={post.id}
                className="bg-background/10 rounded-lg p-6 border border-background/20 hover:border-accent transition-all duration-300 group cursor-pointer"
              >
                <div className="mb-4">
                  <span className="bg-accent/20 text-accent px-3 py-1 rounded-full text-xs font-semibold">
                    {post.category}
                  </span>
                </div>
                <h3 className="text-lg font-bold text-background mb-3 group-hover:text-accent transition-colors">
                  {post.title}
                </h3>
                <p className="text-sm text-background/80 mb-4">{post.excerpt}</p>
                <div className="flex flex-wrap gap-3 text-xs text-background/70 mb-4">
                  <div className="flex items-center gap-1">
                    <User className="w-3 h-3" />
                    {post.author}
                  </div>
                  <div className="flex items-center gap-1">
                    <Calendar className="w-3 h-3" />
                    {post.date}
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-background/70">{post.readTime}</span>
                  <ArrowRight className="w-4 h-4 text-accent group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Newsletter CTA */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
            Stay Updated
          </h2>
          <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
            Subscribe to our newsletter for the latest insights, industry trends, and thought leadership delivered to your inbox.
          </p>
          <form className="max-w-md mx-auto flex gap-2">
            <input
              type="email"
              placeholder="Enter your email"
              className="flex-1 px-4 py-3 rounded-lg bg-card text-foreground border border-border focus:outline-none focus:ring-2 focus:ring-accent"
            />
            <button
              type="submit"
              className="px-6 py-3 bg-accent text-accent-foreground rounded-lg font-semibold hover:bg-accent/90 transition-colors"
            >
              Subscribe
            </button>
          </form>
        </div>
      </section>

      <Footer />
    </div>
  );
}
