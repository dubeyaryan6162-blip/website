/**
 * FAQ Page
 * Design System: Bold & Sophisticated
 * Features: Accordion-style FAQs, category filtering
 */

import { useState } from 'react';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { AccentBar } from '@/components/SectionDivider';
import { ChevronDown } from 'lucide-react';

const FAQ_ITEMS = [
  {
    category: 'Services',
    questions: [
      {
        q: 'What services does your company offer?',
        a: 'We provide comprehensive professional services including strategic consulting, implementation and execution, and innovation and growth programs. Each service is tailored to your specific business needs and challenges.',
      },
      {
        q: 'How do you customize solutions for each client?',
        a: 'We begin with an in-depth discovery phase to understand your unique business context, challenges, and goals. This allows us to develop customized strategies and implementation plans rather than applying generic templates.',
      },
      {
        q: 'What industries do you specialize in?',
        a: 'We have deep expertise across multiple industries including financial services, retail, manufacturing, technology, and healthcare. Our diverse experience allows us to bring best practices and innovative solutions across sectors.',
      },
    ],
  },
  {
    category: 'Engagement',
    questions: [
      {
        q: 'How long does a typical engagement take?',
        a: 'Engagement duration varies based on scope and complexity. Strategic consulting projects typically range from 3-6 months, while implementation programs can extend 6-12 months or longer depending on your needs.',
      },
      {
        q: 'What is your team composition?',
        a: 'Our teams combine senior strategists, implementation specialists, and subject matter experts. We tailor team composition to match your project requirements and ensure the right expertise is applied.',
      },
      {
        q: 'How do you measure success?',
        a: 'We establish clear KPIs and success metrics at the outset of every engagement. Regular reporting and transparent communication ensure alignment on progress and outcomes throughout the project.',
      },
    ],
  },
  {
    category: 'Process',
    questions: [
      {
        q: 'What is your approach to change management?',
        a: 'We recognize that successful implementation requires organizational alignment and stakeholder buy-in. Our change management approach includes communication planning, training, and ongoing support to ensure adoption.',
      },
      {
        q: 'How do you ensure knowledge transfer?',
        a: 'Knowledge transfer is built into every engagement. We provide training, documentation, and ongoing support to ensure your team has the skills and understanding to sustain results after our engagement concludes.',
      },
      {
        q: 'Do you provide post-implementation support?',
        a: 'Yes, we offer flexible post-implementation support options including performance monitoring, optimization recommendations, and ongoing advisory services to ensure sustained success.',
      },
    ],
  },
];

export default function FAQ() {
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const toggleExpanded = (id: string) => {
    setExpandedId(expandedId === id ? null : id);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-b from-secondary to-background">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl">
            <AccentBar width="w-16" color="#0ea5a5" />
            <h1 className="text-5xl md:text-6xl font-bold text-foreground mt-4 mb-6">
              Frequently Asked Questions
            </h1>
            <p className="text-xl text-muted-foreground">
              Find answers to common questions about our services, engagement process, and how we work with clients.
            </p>
          </div>
        </div>
      </section>

      {/* FAQ Content */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl">
            {FAQ_ITEMS.map((category, catIdx) => (
              <div key={catIdx} className="mb-16">
                <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-8">
                  {category.category}
                </h2>

                <div className="space-y-4">
                  {category.questions.map((item, qIdx) => {
                    const itemId = `${catIdx}-${qIdx}`;
                    const isExpanded = expandedId === itemId;

                    return (
                      <div
                        key={itemId}
                        className="border border-border rounded-lg overflow-hidden hover:border-accent transition-colors duration-300"
                      >
                        <button
                          onClick={() => toggleExpanded(itemId)}
                          className="w-full px-6 py-4 flex items-start justify-between bg-card hover:bg-secondary transition-colors duration-200"
                        >
                          <span className="text-left font-semibold text-foreground pr-4">
                            {item.q}
                          </span>
                          <ChevronDown
                            className={`w-5 h-5 text-accent flex-shrink-0 transition-transform duration-300 ${
                              isExpanded ? 'rotate-180' : ''
                            }`}
                          />
                        </button>

                        {isExpanded && (
                          <div className="px-6 py-4 bg-background border-t border-border">
                            <p className="text-muted-foreground leading-relaxed">{item.a}</p>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-foreground text-background">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-6" style={{ fontFamily: "'Playfair Display', serif" }}>
            Didn't Find Your Answer?
          </h2>
          <p className="text-lg text-background/80 mb-8 max-w-2xl mx-auto">
            Our team is here to help. Reach out with any questions about our services or how we can support your organization.
          </p>
          <a href="/contact" className="inline-block px-8 py-3 bg-accent text-accent-foreground rounded-lg font-semibold hover:bg-accent/90 transition-colors">
            Contact Us
          </a>
        </div>
      </section>

      <Footer />
    </div>
  );
}
