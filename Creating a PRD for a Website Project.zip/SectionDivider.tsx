/**
 * SectionDivider Component
 * Design System: Bold & Sophisticated
 * Purpose: Create smooth, asymmetric transitions between sections using SVG curves
 * Signature Element: Diagonal section dividers create visual rhythm and prevent monotony
 */

interface SectionDividerProps {
  position?: 'top' | 'bottom';
  color?: string;
  className?: string;
}

export function SectionDivider({ 
  position = 'bottom', 
  color = '#f8f5f0',
  className = ''
}: SectionDividerProps) {
  if (position === 'top') {
    return (
      <svg
        viewBox="0 0 1200 120"
        preserveAspectRatio="none"
        className={`w-full h-auto ${className}`}
        style={{ display: 'block' }}
      >
        <path
          d="M0,60 Q300,0 600,60 T1200,60 L1200,0 L0,0 Z"
          fill={color}
        />
      </svg>
    );
  }

  return (
    <svg
      viewBox="0 0 1200 120"
      preserveAspectRatio="none"
      className={`w-full h-auto ${className}`}
      style={{ display: 'block' }}
    >
      <path
        d="M0,60 Q300,120 600,60 T1200,60 L1200,120 L0,120 Z"
        fill={color}
      />
    </svg>
  );
}

/**
 * AccentBar Component
 * Design System: Bold & Sophisticated
 * Purpose: Thin, geometric accent lines that frame key content
 * Signature Element: Teal accent bars draw attention without overwhelming
 */

interface AccentBarProps {
  orientation?: 'horizontal' | 'vertical';
  width?: string;
  color?: string;
  className?: string;
}

export function AccentBar({ 
  orientation = 'horizontal', 
  width = 'w-16',
  color = '#0ea5a5',
  className = ''
}: AccentBarProps) {
  if (orientation === 'vertical') {
    return (
      <div 
        className={`${width} h-1 ${className}`}
        style={{ backgroundColor: color }}
      />
    );
  }

  return (
    <div 
      className={`h-1 ${width} ${className}`}
      style={{ backgroundColor: color }}
    />
  );
}

/**
 * LayeredCard Component
 * Design System: Bold & Sophisticated
 * Purpose: Cards with subtle shadows, offset borders, and teal accents
 * Signature Element: Layered card design creates depth and visual interest
 */

interface LayeredCardProps {
  children: React.ReactNode;
  className?: string;
  withAccent?: boolean;
}

export function LayeredCard({ 
  children, 
  className = '',
  withAccent = true
}: LayeredCardProps) {
  return (
    <div className={`relative ${className}`}>
      {withAccent && (
        <div 
          className="absolute -inset-1 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300"
          style={{ 
            background: 'linear-gradient(135deg, #0ea5a5 0%, transparent 100%)',
            zIndex: -1
          }}
        />
      )}
      <div 
        className="relative bg-card text-card-foreground rounded-lg p-6 shadow-md hover:shadow-xl transition-shadow duration-300 border border-border"
        style={{
          borderLeft: withAccent ? '4px solid #0ea5a5' : 'none'
        }}
      >
        {children}
      </div>
    </div>
  );
}
