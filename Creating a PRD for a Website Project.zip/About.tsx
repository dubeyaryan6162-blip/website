/**
 * About Us Page
 * Design System: Bold & Sophisticated
 * Features: Mission statement, team overview, company values, timeline
 */

import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { SectionDivider, AccentBar, LayeredCard } from '@/components/SectionDivider';

export default function About() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-b from-secondary to-background">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl">
            <AccentBar width="w-16" color="#0ea5a5" />
            <h1 className="text-5xl md:text-6xl font-bold text-foreground mt-4 mb-6">
              About Services Co.
            </h1>
            <p className="text-xl text-muted-foreground">
              We're a forward-thinking professional services firm dedicated to helping organizations anticipate challenges and seize opportunities through innovative, data-driven solutions.
            </p>
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <LayeredCard withAccent>
              <h3 className="text-2xl font-bold text-foreground mb-4">Our Mission</h3>
              <p className="text-muted-foreground leading-relaxed">
                To empower organizations with strategic insights and innovative solutions that drive sustainable growth, foster innovation, and create lasting competitive advantage in an increasingly complex business landscape.
              </p>
            </LayeredCard>

            <LayeredCard withAccent>
              <h3 className="text-2xl font-bold text-foreground mb-4">Our Vision</h3>
              <p className="text-muted-foreground leading-relaxed">
                To be the most trusted partner for organizations seeking transformative change—recognized for our deep expertise, innovative thinking, and unwavering commitment to client success.
              </p>
            </LayeredCard>
          </div>
        </div>
      </section>

      {/* Core Values */}
      <section className="py-20 bg-foreground text-background">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl md:text-5xl font-bold mb-12 text-center" style={{ fontFamily: "'Playfair Display', serif" }}>
            Our Core Values
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                title: 'Excellence',
                description: 'We pursue the highest standards in everything we do, from strategy to execution.',
              },
              {
                title: 'Innovation',
                description: 'We challenge conventions and embrace creative thinking to solve complex problems.',
              },
              {
                title: 'Integrity',
                description: 'We build trust through transparency, honesty, and unwavering ethical standards.',
              },
              {
                title: 'Collaboration',
                description: 'We believe the best solutions emerge from diverse perspectives and teamwork.',
              },
            ].map((value, idx) => (
              <div
                key={idx}
                className="p-6 bg-background/10 rounded-lg border border-background/20 hover:border-accent transition-colors duration-300"
              >
                <h3 className="text-lg font-bold mb-3">{value.title}</h3>
                <p className="text-sm text-background/80">{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Divider */}
      <SectionDivider position="bottom" color="#f8f5f0" />

      {/* Team Section */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <div className="mb-12">
            <AccentBar width="w-16" color="#0ea5a5" />
            <h2 className="text-4xl md:text-5xl font-bold text-foreground mt-4 mb-4">
              Our Leadership Team
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl">
              Seasoned professionals with deep industry expertise and a passion for driving transformative change.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                name: 'Sarah Johnson',
                role: 'Chief Executive Officer',
                bio: '20+ years in strategic consulting with a track record of transforming Fortune 500 companies.',
              },
              {
                name: 'Michael Chen',
                role: 'Chief Strategy Officer',
                bio: 'Expert in digital transformation and innovation strategy with global experience.',
              },
              {
                name: 'Emily Rodriguez',
                role: 'Chief Operations Officer',
                bio: 'Specializes in operational excellence and scaling high-performing teams.',
              },
            ].map((member, idx) => (
              <LayeredCard key={idx} withAccent>
                <div className="w-full h-48 bg-secondary rounded-lg mb-4" />
                <h3 className="text-xl font-bold text-foreground mb-1">{member.name}</h3>
                <p className="text-accent font-semibold mb-3">{member.role}</p>
                <p className="text-muted-foreground text-sm">{member.bio}</p>
              </LayeredCard>
            ))}
          </div>
        </div>
      </section>

      {/* Company Timeline */}
      <section className="py-20 bg-secondary">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-12 text-center">
            Our Journey
          </h2>

          <div className="max-w-3xl mx-auto">
            {[
              { year: '2010', event: 'Founded with a mission to revolutionize professional services.' },
              { year: '2014', event: 'Expanded to 50+ team members and opened second office.' },
              { year: '2018', event: 'Reached $10M in annual revenue and launched innovation lab.' },
              { year: '2022', event: 'Became industry leader with 200+ successful transformations.' },
              { year: '2024', event: 'Expanded globally with offices in 5 countries.' },
            ].map((milestone, idx) => (
              <div key={idx} className="flex gap-8 mb-8 last:mb-0">
                <div className="flex-shrink-0 w-24 text-right">
                  <span className="text-2xl font-bold text-accent">{milestone.year}</span>
                </div>
                <div className="flex-1 pb-8 border-l-2 border-accent pl-8 relative">
                  <div className="absolute -left-3 top-0 w-4 h-4 bg-accent rounded-full" />
                  <p className="text-foreground">{milestone.event}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
