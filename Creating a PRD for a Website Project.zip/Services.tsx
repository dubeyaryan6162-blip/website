/**
 * Services Page
 * Design System: Bold & Sophisticated
 * Features: Detailed service descriptions, process overview, case studies
 */

import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { SectionDivider, AccentBar, LayeredCard } from '@/components/SectionDivider';
import { CheckCircle } from 'lucide-react';

export default function Services() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-b from-secondary to-background">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl">
            <AccentBar width="w-16" color="#0ea5a5" />
            <h1 className="text-5xl md:text-6xl font-bold text-foreground mt-4 mb-6">
              Our Services
            </h1>
            <p className="text-xl text-muted-foreground">
              Comprehensive solutions designed to address your unique business challenges and unlock new opportunities for growth.
            </p>
          </div>
        </div>
      </section>

      {/* Service Categories */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <div className="space-y-20">
            {/* Service 1 */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
                  Strategic Consulting
                </h2>
                <p className="text-muted-foreground mb-6 leading-relaxed">
                  Navigate complex business challenges with data-driven insights and actionable strategies. Our consultants work closely with your leadership team to identify opportunities, mitigate risks, and chart a clear path to sustainable growth.
                </p>
                <ul className="space-y-3">
                  {[
                    'Market analysis and competitive positioning',
                    'Business model innovation',
                    'Digital transformation roadmaps',
                    'Organizational restructuring',
                  ].map((item, idx) => (
                    <li key={idx} className="flex items-center gap-3">
                      <CheckCircle className="w-5 h-5 text-accent flex-shrink-0" />
                      <span className="text-foreground">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div className="bg-secondary rounded-lg h-80" />
            </div>

            {/* Service 2 */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <div className="bg-secondary rounded-lg h-80 md:order-2" />
              <div className="md:order-1">
                <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
                  Implementation & Execution
                </h2>
                <p className="text-muted-foreground mb-6 leading-relaxed">
                  Transform strategy into reality. Our implementation experts ensure seamless execution, stakeholder alignment, and measurable results. We manage complexity so you can focus on business outcomes.
                </p>
                <ul className="space-y-3">
                  {[
                    'Change management and adoption',
                    'Technology implementation',
                    'Process optimization',
                    'Performance tracking and reporting',
                  ].map((item, idx) => (
                    <li key={idx} className="flex items-center gap-3">
                      <CheckCircle className="w-5 h-5 text-accent flex-shrink-0" />
                      <span className="text-foreground">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Service 3 */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
                  Innovation & Growth
                </h2>
                <p className="text-muted-foreground mb-6 leading-relaxed">
                  Stay ahead of market disruption. Our innovation programs help you identify emerging trends, develop new business models, and accelerate growth through creative problem-solving and experimentation.
                </p>
                <ul className="space-y-3">
                  {[
                    'Innovation workshops and ideation',
                    'New product development',
                    'Go-to-market strategies',
                    'Growth acceleration programs',
                  ].map((item, idx) => (
                    <li key={idx} className="flex items-center gap-3">
                      <CheckCircle className="w-5 h-5 text-accent flex-shrink-0" />
                      <span className="text-foreground">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div className="bg-secondary rounded-lg h-80" />
            </div>
          </div>
        </div>
      </section>

      {/* Divider */}
      <SectionDivider position="bottom" color="#f8f5f0" />

      {/* Our Process */}
      <section className="py-20 bg-foreground text-background">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl md:text-5xl font-bold mb-12 text-center" style={{ fontFamily: "'Playfair Display', serif" }}>
            Our Proven Process
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {[
              { step: '01', title: 'Discovery', desc: 'Deep dive into your business, challenges, and goals.' },
              { step: '02', title: 'Strategy', desc: 'Develop tailored solutions and implementation roadmap.' },
              { step: '03', title: 'Execution', desc: 'Implement with precision and manage stakeholders.' },
              { step: '04', title: 'Optimize', desc: 'Monitor results and continuously improve outcomes.' },
            ].map((phase, idx) => (
              <div key={idx} className="relative">
                <div className="text-5xl font-bold text-accent/20 mb-2">{phase.step}</div>
                <h3 className="text-xl font-bold mb-2">{phase.title}</h3>
                <p className="text-sm text-background/80">{phase.desc}</p>
                {idx < 3 && (
                  <div className="hidden md:block absolute -right-3 top-8 text-accent text-2xl">→</div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Case Studies */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <div className="mb-12">
            <AccentBar width="w-16" color="#0ea5a5" />
            <h2 className="text-4xl md:text-5xl font-bold text-foreground mt-4 mb-4">
              Case Studies
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl">
              See how we've helped leading organizations achieve transformative results.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {[
              {
                title: 'Digital Transformation for Fortune 500 Retailer',
                challenge: 'Legacy systems hindering growth in e-commerce',
                result: '40% increase in online sales, 60% reduction in operational costs',
              },
              {
                title: 'Market Entry Strategy for Tech Startup',
                challenge: 'Entering competitive market with limited resources',
                result: 'Successful launch in 3 new markets, $50M Series B funding',
              },
              {
                title: 'Organizational Restructuring for Financial Services',
                challenge: 'Inefficient processes and siloed departments',
                result: '25% improvement in productivity, enhanced customer satisfaction',
              },
              {
                title: 'Innovation Program for Manufacturing Leader',
                challenge: 'Declining market share due to product commoditization',
                result: '3 new products launched, 35% revenue growth',
              },
            ].map((study, idx) => (
              <LayeredCard key={idx} withAccent>
                <h3 className="text-xl font-bold text-foreground mb-4">{study.title}</h3>
                <div className="space-y-3">
                  <div>
                    <p className="text-sm font-semibold text-accent mb-1">Challenge</p>
                    <p className="text-muted-foreground text-sm">{study.challenge}</p>
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-accent mb-1">Result</p>
                    <p className="text-muted-foreground text-sm">{study.result}</p>
                  </div>
                </div>
              </LayeredCard>
            ))}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
