# Quick Start Guide

## 1️⃣ Setup (5 minutes)

```bash
# Extract the ZIP file
unzip professional-services-website.zip
cd client_website

# Install dependencies
pnpm install

# Start development server
pnpm dev
```

Visit `http://localhost:5173` in your browser.

## 2️⃣ Customize Your Content

### Update Company Name
Search for "Services Co." and replace with your company name in:
- `client/src/components/Header.tsx`
- `client/src/components/Footer.tsx`
- `client/src/pages/Home.tsx`
- `client/src/pages/About.tsx`

### Update Contact Information
Edit `client/src/components/Footer.tsx`:
```tsx
const contactInfo = {
  email: 'your-email@company.com',
  phone: '+1 (234) 567-890',
  address: '123 Business Ave, City, State 12345',
};
```

### Update Services
Edit `client/src/pages/Services.tsx` and replace service descriptions with your actual services.

### Add Your Logo
Replace the logo URL in `client/src/components/Header.tsx`:
```tsx
const LOGO_URL = 'your-logo-url-here';
```

## 3️⃣ Update Colors (Optional)

Edit `client/src/index.css` to change the color scheme:
```css
:root {
  --primary: #0ea5a5;           /* Main brand color (teal) */
  --foreground: #1a2332;        /* Text color (navy) */
  --background: #f8f5f0;        /* Background (cream) */
}
```

## 4️⃣ Deploy to GitHub

```bash
# Initialize git (if not already done)
git init

# Add all files
git add .

# Create initial commit
git commit -m "Initial commit: Professional Services Website"

# Add remote repository
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO_NAME.git

# Push to GitHub
git branch -M main
git push -u origin main
```

## 5️⃣ Build for Production

```bash
pnpm build
```

This creates a `dist/` folder with optimized production files.

## 📂 File Structure

```
client_website/
├── client/src/
│   ├── pages/           ← Edit page content here
│   ├── components/      ← Reusable components
│   ├── index.css        ← Global styles & colors
│   └── App.tsx          ← Routing setup
├── package.json         ← Dependencies
└── README.md            ← Project documentation
```

## 🎯 Next Steps

1. ✅ Customize company information
2. ✅ Update services and descriptions
3. ✅ Add your logo and images
4. ✅ Update contact information
5. ✅ Deploy to GitHub
6. ✅ Deploy to hosting (Vercel, Netlify, etc.)

## 🚀 Deployment Options

### Vercel (Recommended)
```bash
npm install -g vercel
vercel
```

### Netlify
```bash
npm install -g netlify-cli
netlify deploy
```

### GitHub Pages
Add to `package.json`:
```json
"homepage": "https://YOUR_USERNAME.github.io/YOUR_REPO_NAME"
```

Then run:
```bash
pnpm build
```

## 💡 Tips

- Use `pnpm dev` for local development
- Use `pnpm check` to verify TypeScript types
- Use `pnpm format` to format code
- Check `.manus-logs/` for development logs

## ❓ Common Issues

**Port 5173 already in use?**
```bash
pnpm dev -- --port 3000
```

**Dependencies not installing?**
```bash
rm -rf node_modules pnpm-lock.yaml
pnpm install
```

**TypeScript errors?**
```bash
pnpm check
```

---

Happy coding! 🎉
