# Professional Services Website

A modern, responsive, and production-ready professional services website built with React, TypeScript, and Tailwind CSS.

## 🎨 Design Features

- **Bold & Sophisticated Design System**
- **Color Palette:** Navy (#1a2332), Teal (#0ea5a5), Cream (#f8f5f0)
- **Typography:** Playfair Display (headlines) + Inter (body)
- **Responsive Design:** Mobile, tablet, and desktop optimized
- **Smooth Animations:** Hover effects, transitions, and micro-interactions
- **Premium Components:** Layered cards, section dividers, accent bars

## 📄 Pages Included

1. **Homepage** - Hero section, services preview, CTA sections
2. **About Us** - Company mission, vision, core values, team
3. **Services** - Detailed service offerings, process, case studies
4. **Blog** - Featured articles, recent posts, newsletter signup
5. **FAQ** - Accordion-style Q&A organized by category
6. **Contact** - Contact form with validation, company info
7. **Privacy Policy** - Legal compliance page
8. **Terms of Service** - Legal compliance page

## 🛠️ Tech Stack

- **Frontend Framework:** React 19
- **Language:** TypeScript
- **Styling:** Tailwind CSS 4
- **UI Components:** shadcn/ui
- **Routing:** Wouter
- **Icons:** Lucide React
- **Build Tool:** Vite
- **Package Manager:** pnpm

## 📦 Project Structure

```
client_website/
├── client/
│   ├── public/              # Static assets (favicon, robots.txt)
│   ├── src/
│   │   ├── components/      # Reusable UI components
│   │   │   ├── ui/         # shadcn/ui components
│   │   │   ├── Header.tsx
│   │   │   ├── Footer.tsx
│   │   │   └── SectionDivider.tsx
│   │   ├── pages/          # Page components
│   │   │   ├── Home.tsx
│   │   │   ├── About.tsx
│   │   │   ├── Services.tsx
│   │   │   ├── Blog.tsx
│   │   │   ├── FAQ.tsx
│   │   │   ├── Contact.tsx
│   │   │   ├── Privacy.tsx
│   │   │   └── Terms.tsx
│   │   ├── contexts/       # React contexts
│   │   ├── hooks/          # Custom React hooks
│   │   ├── lib/            # Utility functions
│   │   ├── App.tsx         # Main app component with routing
│   │   ├── main.tsx        # React entry point
│   │   └── index.css       # Global styles & design tokens
│   └── index.html          # HTML template
├── server/                 # Express server (placeholder)
├── shared/                 # Shared types (placeholder)
├── package.json
├── tsconfig.json
├── vite.config.ts
└── tailwind.config.ts
```

## 🚀 Getting Started

### Prerequisites
- Node.js 18+ 
- pnpm (or npm/yarn)

### Installation

1. **Clone or extract the project:**
```bash
unzip professional-services-website.zip
cd client_website
```

2. **Install dependencies:**
```bash
pnpm install
```

3. **Start development server:**
```bash
pnpm dev
```

The site will be available at `http://localhost:5173`

### Build for Production

```bash
pnpm build
```

This creates an optimized build in the `dist/` directory.

### Preview Production Build

```bash
pnpm preview
```

## 🎯 Key Components

### Header Component
- Sticky navigation with smooth scroll transitions
- Responsive mobile menu
- Brand logo and navigation links
- CTA button

### Footer Component
- Quick navigation links
- Contact information
- Legal links (Privacy, Terms)
- Social media placeholders

### SectionDivider Component
- Custom SVG dividers between sections
- Smooth transitions between color backgrounds
- Accent bars for visual hierarchy

### LayeredCard Component
- Styled cards with optional teal accent
- Shadow effects and hover animations
- Flexible content layout

## 🎨 Customization Guide

### Update Brand Colors
Edit `client/src/index.css` and modify the CSS variables in `:root`:
```css
:root {
  --primary: #0ea5a5;        /* Teal */
  --foreground: #1a2332;     /* Navy */
  /* ... other colors */
}
```

### Update Company Information
- **Header Logo:** Change `LOGO_URL` in `client/src/components/Header.tsx`
- **Company Name:** Update "Services Co." throughout the site
- **Contact Info:** Update in `client/src/components/Footer.tsx` and `client/src/pages/Contact.tsx`

### Update Content
Replace placeholder content in each page component:
- `client/src/pages/Home.tsx`
- `client/src/pages/About.tsx`
- `client/src/pages/Services.tsx`
- etc.

### Update Images
Replace image URLs with your own:
```tsx
const HERO_BG = 'your-image-url-here';
const SERVICES_HERO = 'your-image-url-here';
```

## 📱 Responsive Design

The website is fully responsive with breakpoints:
- **Mobile:** < 640px
- **Tablet:** 640px - 1024px
- **Desktop:** > 1024px

All components adapt gracefully to different screen sizes.

## ♿ Accessibility

- Semantic HTML structure
- ARIA labels where needed
- Keyboard navigation support
- Color contrast compliance
- Focus indicators on interactive elements

## 🔧 Available Scripts

```bash
# Development
pnpm dev          # Start dev server

# Production
pnpm build        # Build for production
pnpm preview      # Preview production build

# Code Quality
pnpm check        # TypeScript type checking
pnpm format       # Format code with Prettier
```

## 📝 License

This project is open source and available under the MIT License.

## 🤝 Contributing

Feel free to fork this project and customize it for your needs. If you make improvements, consider sharing them back!

## 📧 Support

For questions or issues, please create an issue in the repository or contact the development team.

---

**Built with ❤️ using React, TypeScript, and Tailwind CSS**
